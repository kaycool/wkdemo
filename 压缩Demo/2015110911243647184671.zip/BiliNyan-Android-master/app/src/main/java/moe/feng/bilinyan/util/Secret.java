package moe.feng.bilinyan.util;

/**
 * Created by Administrator on 2015/11/5 0005.
 */
public class Secret {

    public static final String APP_KEY = "";
    public static final String APP_SECRET = "";

}
