package moe.feng.bilinyan.ui.fragment;

import android.os.Bundle;

import moe.feng.bilinyan.R;
import moe.feng.bilinyan.ui.common.LazyFragment;

public class SectionDiscoverFragment extends LazyFragment {

	@Override
	public int getLayoutResId() {
		return R.layout.fragment_section_discover;
	}

	@Override
	public void finishCreateView(Bundle state) {
	}

}
