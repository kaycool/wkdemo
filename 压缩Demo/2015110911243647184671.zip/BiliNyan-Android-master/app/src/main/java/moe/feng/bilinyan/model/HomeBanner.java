package moe.feng.bilinyan.model;

public class HomeBanner {

	public String img;
	public String title;
	public String link;

}
