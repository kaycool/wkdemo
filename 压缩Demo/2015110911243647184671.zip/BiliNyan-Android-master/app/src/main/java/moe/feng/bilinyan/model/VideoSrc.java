package moe.feng.bilinyan.model;

public class VideoSrc {

	public String img; // 视频预览
	public String cid; // 弹幕文件
	public String src; // 视频源地址

}
