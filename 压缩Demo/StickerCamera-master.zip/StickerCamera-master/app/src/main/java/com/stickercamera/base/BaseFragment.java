package com.stickercamera.base;

import android.support.v4.app.Fragment;

/**
 * Created by sky on 15/7/6.
 */
public class BaseFragment extends Fragment {



}
