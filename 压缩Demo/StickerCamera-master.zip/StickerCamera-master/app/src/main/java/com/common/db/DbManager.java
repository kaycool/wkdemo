package com.common.db;


/**
 * Created by sky on 15/7/6.
 */
public class DbManager {


}
