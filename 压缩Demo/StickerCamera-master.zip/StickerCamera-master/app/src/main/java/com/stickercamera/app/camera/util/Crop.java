package com.stickercamera.app.camera.util;

/**
 * 裁剪常量
 * Created by sky on 2015/7/8.
 */
public class Crop {

    public static final int REQUEST_CROP = 6709;
    public static final int REQUEST_PICK = 9162;
    public static final int RESULT_ERROR = 404;

}
