package com.picturetagview;

import android.app.Activity;
import android.os.Bundle;

public class MainAct extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.act_main);
	}
}
