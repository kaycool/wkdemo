# PictureTagView
最近打标签的应用很火，就随便写了写，仿nice图片上打标签控件demo，提供给有需要的人一点思路吧。
原理其实很简单，自定义一个layout，图片作为background，然后监听ontouch，通过变动的手指位置改变子控件位置。

点击图片没有标签的部分即可添加新标签，点击标签实现即时编辑，支持拖动标签改变位置
## Demo 图片
![](https://github.com/saiwu-bigkoo/PictureTagView/blob/master/preview/picturetagviewdemo.gif)
