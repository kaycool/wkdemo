package com.ygycomon.testtitledlistview;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import com.zwj.testtitledlistview.R;

public class MainActivity extends Activity implements OnScrollListener{
	
	private TitledListView listview;
    private List<Entry> datas;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        listview = (TitledListView) findViewById(R.id.titledListView);
        datas = initData();
        TitledListAdapter adapter = new TitledListAdapter(this, datas);
        listview.setAdapter(adapter);
        listview.setOnScrollListener(this);
    }

    private List<Entry> initData() {   
        List<Entry> entrys = new ArrayList<Entry>();
        
        for (int i = 0; i < 60; i++) {
            Entry entry = new Entry();
            entry.setContent("" + i);
            entry.setTitle("����" + (i / 6));
            entrys.add(entry);
        }
        
        return entrys;
    }

	@Override
	public void onScrollStateChanged(AbsListView view, int scrollState) {
		
	}

	@Override
	public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
		// ��һ����ڶ�����ⲻͬ��˵��������Ҫ�ƶ�
        if (!datas.get(firstVisibleItem).getTitle().equals(datas.get(firstVisibleItem + 1).getTitle())) {
            ((TitledListView) view).moveTitle();
        } else {
            ((TitledListView) view).updateTitle(datas.get(firstVisibleItem).getTitle());
        }
	}
}
