package com.ygycomon.testtitledlistview;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.zwj.testtitledlistview.R;

public class TitledListAdapter extends BaseAdapter {
	
    private List<Entry> datas;
    private Context context;

    public TitledListAdapter(Context context, List<Entry> datas) {
        this.context = context;
        this.datas = datas;
    }

    @Override
    public int getCount() {
        return datas.size();
    }

    @Override
    public Object getItem(int position) {
        return datas.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.listitem, null);
        TextView content = (TextView) view.findViewById(R.id.content);
        TextView title = (TextView) view.findViewById(R.id.title);
        
        content.setText(datas.get(position).content);
        title.setText(datas.get(position).getTitle());
        
        //��һ���ǰ��ͬ������Ҫ��ʾ���⣬��������
        if (position == 0) {
            title.setVisibility(View.VISIBLE);
        } else if (position < getCount() && !datas.get(position).getTitle().equals(datas.get(position - 1).getTitle())) {
            title.setVisibility(View.VISIBLE);
        } else {
            title.setVisibility(View.GONE);
        }
        
        return view;
    }

}