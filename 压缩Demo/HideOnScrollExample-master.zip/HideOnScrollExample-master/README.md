HideOnScrollExample
=============

This example shows how to show/hide views (i.e. Toolbar or FAB) when a list is scrolled up/down.

There is a blog post explaining the code: 

[part 1](http://mzgreen.github.io/2015/02/15/How-to-hideshow-Toolbar-when-list-is-scroling%28part1%29/)

[part 2](http://mzgreen.github.io/2015/02/28/How-to-hideshow-Toolbar-when-list-is-scrolling%28part2%29/)

