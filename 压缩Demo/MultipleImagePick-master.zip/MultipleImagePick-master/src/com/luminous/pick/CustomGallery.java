package com.luminous.pick;

public class CustomGallery {

	public String sdcardPath;
	public boolean isSeleted = false;

}
